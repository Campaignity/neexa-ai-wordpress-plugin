=== Neexa AI Agents ===
Contributors: neexa
Tags: Chatbot, AI, Salesbot, Agent
Requires at least: 4.7
Tested up to: 6.3
Stable tag: 1.0
Requires PHP: 7.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Here is a short description of the plugin.  This should be no more than 150 characters.  No markup here.

== Description ==

This plugin seamlessly integrates Neexa.AI's 24/7 AI Powered Sales Agent onto any WordPress site.

== Frequently Asked Questions ==

= Does it show right away? =

Yes, as long as the AI Agent corresponds to one in your Neexa.AI dashboard.

== Screenshots ==

1. This this is your neexa.ai dashboard as you receive the conversations.

== Changelog ==

= 1.0 =
* This is the initial version and allows for setting AI Agent ID